package com.example.samuraitravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Samuraitravel2Application {

	public static void main(String[] args) {
		SpringApplication.run(Samuraitravel2Application.class, args);
	}

}
