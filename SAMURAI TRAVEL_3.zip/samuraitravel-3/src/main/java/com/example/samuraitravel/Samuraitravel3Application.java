package com.example.samuraitravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Samuraitravel3Application {

	public static void main(String[] args) {
		SpringApplication.run(Samuraitravel3Application.class, args);
	}

}
