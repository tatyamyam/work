 const stripe = Stripe('pk_test_51Nts9PJJS1k5bMFZHtGol4YjAy6BcFEKgzhL23nggdGS9vho75zTUzNBiLrbNNIFGercLteHljH5xhDFovb2W65F00XbvbYUrT');
 const paymentButton = document.querySelector('#paymentButton');
 
 paymentButton.addEventListener('click', () => {
   stripe.redirectToCheckout({
     sessionId: sessionId
   })
 });